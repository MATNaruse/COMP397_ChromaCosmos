// Immediate Invoked Anonymous Function
(function () {
    // Global Game Variables
    var canvas = document.getElementById("canvas");
    var stage;
    var assetManager;
    var assetManifest;
    // Store current scene information
    var currentScene;
    var currentState;
    assetManifest = [
        { id: "background", src: "./Assets/background2.jpg" },
        { id: "player", src: "./Assets/spaceship.png" },
        // Bullet Colours
        { id: "bulletRED", src: "./Assets/bullets/bulletRed.png" },
        { id: "bulletBLUE", src: "./Assets/bullets/bulletBlue.png" },
        { id: "bulletYELLOW", src: "./Assets/bullets/bulletYellow.png" },
        { id: "bulletGREEN", src: "./Assets/bullets/bulletGreen.png" },
        { id: "bulletPURPLE", src: "./Assets/bullets/bulletPurple.png" },
        { id: "bulletORANGE", src: "./Assets/bullets/bulletOrange.png" },
        // Enemies
        { id: "alienRED", src: "./Assets/aliens/alienRed.png" },
        { id: "alienBLUE", src: "./Assets/aliens/alienBlue.png" },
        { id: "alienYELLOW", src: "./Assets/aliens/alienYellow.png" },
        { id: "alienGREEN", src: "./Assets/aliens/alienGreen.png" },
        { id: "alienPURPLE", src: "./Assets/aliens/alienPurple.png" },
        { id: "alienORANGE", src: "./Assets/aliens/alienOrange.png" },
        // Colour Chamber -> Temp Changed to Style 2
        { id: "chamberEMPTY", src: "./Assets/hud/chamberEmpty2.png" },
        { id: "chamberRED", src: "./Assets/hud/chamberRed2.png" },
        { id: "chamberBLUE", src: "./Assets/hud/chamberBlue2.png" },
        { id: "chamberYELLOW", src: "./Assets/hud/chamberYellow2.png" },
        { id: "chamberGREEN", src: "./Assets/hud/chamberGreen2.png" },
        { id: "chamberPURPLE", src: "./Assets/hud/chamberPurple2.png" },
        { id: "chamberORANGE", src: "./Assets/hud/chamberOrange2.png" }
    ];
    function Init() {
        console.log("Initializing Start");
        assetManager = new createjs.LoadQueue();
        assetManager.installPlugin(createjs.Sound);
        assetManager.loadManifest(assetManifest);
        assetManager.on("complete", Start, this);
        //Tracking Canvas Size based on HTML
        objects.Game.canvasW = canvas.clientWidth;
        objects.Game.canvasH = canvas.clientHeight;
    }
    function Start() {
        console.log("Starting Application...");
        // Initialize CreateJS
        stage = new createjs.Stage(canvas);
        stage.enableMouseOver(20);
        createjs.Ticker.framerate = 60;
        createjs.Ticker.on("tick", Update);
        // Set up default game states -- State Machine
        objects.Game.stage = stage;
        objects.Game.currentScene = config.Scene.START;
        currentState = config.Scene.START;
        Main();
    }
    function Update() {
        // Has my state changed since the last check?
        if (currentState != objects.Game.currentScene) {
            console.log("Changing scenes to " + objects.Game.currentScene);
            Main();
        }
        currentScene.Update();
        stage.update();
    }
    function Main() {
        console.log("Game Start");
        // Finite State Machine
        switch (objects.Game.currentScene) {
            case config.Scene.START:
                stage.removeAllChildren();
                currentScene = new scenes.StartScene(assetManager);
                stage.addChild(currentScene);
                break;
            case config.Scene.GAME:
                stage.removeAllChildren();
                currentScene = new scenes.PlayScene(assetManager);
                stage.addChild(currentScene);
                break;
            case config.Scene.OVER:
                stage.removeAllChildren();
                currentScene = new scenes.GameOverScene(assetManager);
                stage.addChild(currentScene);
                break;
        }
        currentState = objects.Game.currentScene;
    }
    window.onload = Init;
})();
//# sourceMappingURL=game.js.map